"""
Test de bout en bout, en mode local (sans Supabase), sur iPhone et sur ordinateur.

    python3 e2e.py

Nécessite : pip install playwright  (et un Chromium : python3 -m playwright install chromium)
Données 100 % fictives : demo.json (sauvegarde) et demo-releve.pdf (relevé au format LCL).
"""
import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / 'demo.json'
STATEMENT = ROOT / 'demo-releve.pdf'
PORT = 8766
URL = f'http://localhost:{PORT}/'


def clean(s):
    return s.replace(' ', ' ').replace('\xa0', ' ')


def text(loc):
    return clean(loc.inner_text())


def new_page(pw, device, errors, tag, when):
    b = pw.chromium.launch()
    opts = dict(pw.devices[device]) if device else {'viewport': {'width': 1280, 'height': 900}}
    ctx = b.new_context(**opts, locale='fr-FR', timezone_id='Europe/Paris', accept_downloads=True)
    # Toujours en mode local, même si config.js pointe vers une vraie base
    ctx.route('**/config.js', lambda r: r.fulfill(content_type='application/javascript',
                                                  body="export const SUPABASE_URL = ''; export const SUPABASE_KEY = '';"))
    page = ctx.new_page()
    page.on('console', lambda m: m.type == 'error' and errors.append(f'[{tag}] {m.text}'))
    page.on('pageerror', lambda e: errors.append(f'[{tag}] {e}'))
    page.on('dialog', lambda d: d.accept())
    page.clock.set_fixed_time(when)
    page.goto(URL)
    page.get_by_role('button', name='Essayer sans compte (sur cet appareil)').click()
    return b, ctx, page


def add(page, amount, category, spread=None, reimb=False, label=None):
    page.locator('#fab').click()
    page.locator('#f-amount').fill(amount)
    if label:
        page.locator('#f-label').fill(label)
    if spread:
        page.locator('#f-spread').select_option(str(spread))
    if reimb:
        page.locator('#f-reimb').check()
    page.locator('.cat-pick', has_text=category).click()
    expect(page.locator('.sheet')).to_have_count(0)


def scenario(pw, device, errors):
    tag = device or 'ordinateur'
    b, ctx, page = new_page(pw, device, errors, tag, datetime(2026, 5, 25, 12))

    # ── Démarrage : sauvegarde importée depuis l'assistant ──
    expect(page.get_by_role('heading', name='Bienvenue')).to_be_visible()
    page.set_input_files('#import-file', str(FIXTURE))
    expect(page.get_by_test_id('restant')).to_be_visible(timeout=5000)
    # 2 100 − 200 (objectif) − 917,69 (dépensé) − 20,01 (abonnements à venir)
    assert text(page.get_by_test_id('restant')) == '962,30 €', text(page.get_by_test_id('restant'))
    assert text(page.get_by_test_id('depenses')) == '917,69 €'
    assert 'par jour pendant 7 jours' in text(page.locator('.hero'))
    assert 'lundi 25 mai' in text(page.locator('.today')).lower()

    # « À classer » → Transport ; le commerçant est retenu
    expect(page.locator('.inbox .tx')).to_have_count(1)
    page.locator('.inbox .tx').click()
    page.locator('.cat-pick', has_text='Transport').click()
    page.get_by_role('button', name='OK').click()
    expect(page.locator('.inbox')).to_have_count(0)

    # Ajout pré-rempli (comme le bouton d'ajout rapide) : catégorie suggérée
    page.goto(URL + '?ajout=1&montant=4,20%20%E2%82%AC&marchand=Le%20Zinc')
    expect(page.locator('#f-amount')).to_have_value('4,2')
    expect(page.locator('.cat-pick.suggested')).to_contain_text('Bar / resto')
    page.locator('.cat-pick.suggested').click()
    expect(page.locator('#toast')).to_contain_text('Bar / resto')

    # Ajout rapide, dépense lissée, avance à rembourser
    add(page, '12', 'Courses')
    add(page, '90', 'Transport', spread=3, label='Billet de train')
    add(page, '60', 'Bar / resto', reimb=True, label='Avance resto')
    assert text(page.get_by_test_id('depenses')) == '963,89 €', text(page.get_by_test_id('depenses'))  # train : 30 € ce mois-ci
    assert text(page.get_by_test_id('restant')) == '916,10 €'
    expect(page.locator('.refunds .refund-row')).to_have_count(1)
    page.locator('.refunds').get_by_role('button', name='Reçu').click()
    expect(page.locator('[data-form="refund"] [name="amount"]')).to_have_value('60')
    page.locator('[data-form="refund"]').get_by_role('button', name='Enregistrer').click()
    expect(page.locator('.refunds')).to_have_count(0)
    assert text(page.get_by_test_id('restant')) == '916,10 €'          # le remboursement ne compte pas une 2e fois

    # ── Mois suivant : charges fixes automatiques ──
    page.clock.set_fixed_time(datetime(2026, 6, 6, 9))
    page.reload()
    expect(page.locator('.month-title')).to_contain_text('juin 2026')
    assert text(page.get_by_test_id('depenses')) == '830,00 €'      # loyer + épargne auto + 1/3 du train
    page.reload()
    assert text(page.get_by_test_id('depenses')) == '830,00 €'      # pas de doublon

    # ── Import du relevé (PDF au format LCL) ──
    page.set_input_files('#statement-file', str(STATEMENT))
    expect(page.get_by_role('heading', name='Relevé LCL')).to_be_visible(timeout=15000)
    page.locator('[data-form="imp-owner"] [name="name"]').fill('DUPONT ALEX')
    page.locator('[data-form="imp-owner"]').get_by_role('button', name='Appliquer').click()
    stats = text(page.locator('.stats'))
    assert 'À ajouter\n5' in stats and 'Ignorées\n2' in stats and 'Déjà présentes\n1' in stats, stats
    pret = page.locator('.imp-row', has=page.locator('.imp-label', has_text='ECHEANCE PRET')).locator('select')
    pret.select_option('rembourse')
    carrefour = page.locator('.imp-row', has=page.locator('.imp-label', has_text='CARREFOUR'))
    expect(carrefour.locator('select')).to_have_value(carrefour.locator('option', has_text='Courses').get_attribute('value'))
    expect(page.locator('.imp-row', has=page.locator('.imp-label', has_text='SALAIRE')).locator('select')).to_have_value('salaire')
    page.get_by_role('button', name='Importer 7 opérations').click()
    expect(page.locator('#toast')).to_contain_text('4 opérations ajoutées', timeout=10000)
    # salaire du 29 mai : le budget de juin démarre ce jour-là
    assert 'du 29 mai au 30 juin' in text(page.locator('.month-head'))
    assert '2 100,00 €' in text(page.locator('.stat').nth(1))
    expect(page.locator('.refunds .refund-row')).to_have_count(1)     # le prêt, remboursement attendu
    # ré-importer le même relevé : tout est déjà là
    page.set_input_files('#statement-file', str(STATEMENT))
    expect(page.get_by_role('heading', name='Relevé LCL')).to_be_visible(timeout=15000)
    assert 'Déjà présentes\n8' in text(page.locator('.stats'))
    page.get_by_role('button', name='Annuler').click()

    # Mai clôturé : revenus − dépenses (l'avance remboursée ne compte ni en dépense ni en épargne)
    page.locator('[data-act="month-prev"]').click()
    assert text(page.locator('.hero-amount')) == '1 097,71 €', text(page.locator('.hero-amount'))
    assert 'Épargné' in text(page.locator('.hero-label'))
    page.locator('[data-act="month-today"]').click()
    expect(page.locator('.compare .crow').first).to_be_visible()

    # ── Projets, comptes, simulations, réglages ──
    page.locator('#tabs [data-view="projets"]').click()
    assert '1 097,71' in text(page.locator('.hero'))
    form = page.locator('[data-form="proj-add"]')
    form.locator('[name="name"]').fill('Ordinateur')
    form.locator('[name="price"]').fill('900')
    form.get_by_role('button', name='Ajouter').click()
    expect(page.locator('h2', has_text='Mes projets')).to_contain_text('2/3')

    page.locator('#tabs [data-view="comptes"]').click()
    assert 'LCL' in text(page.locator('.list'))                        # créé par l'import, solde du relevé
    page.get_by_role('button', name='+ Ajouter un compte').click()
    page.locator('.chip', has_text='LEP').click()
    page.locator('[data-form="account"] [name="balance"]').fill('500')
    page.locator('[data-form="account"]').get_by_role('button', name='Enregistrer').click()
    expect(page.locator('.hero-amount')).to_have_text('6 113,58\xa0€')   # 3 000 + 2 613,58 + 500

    page.locator('#tabs [data-view="simus"]').click()
    page.locator('[data-tab="pret"]').click()
    assert '186,67' in text(page.locator('#sim-out'))

    page.locator('#tabs [data-view="reglages"]').click()
    assert 'dupont alex' not in text(page.locator('.list').nth(1)).lower()          # pas de règle pour ses propres virements
    assert 'echeance pret personnel' in text(page.locator('#view'))                 # choix retenu pour le prochain relevé
    field = page.locator('.cat-edit', has=page.locator('input[value="Courses"]')).locator('[data-cat="budget"]')
    field.fill('300')
    field.blur()
    page.reload()
    page.locator('#tabs [data-view="reglages"]').click()
    expect(page.locator('.cat-edit', has=page.locator('input[value="Courses"]')).locator('[data-cat="budget"]')).to_have_value('300')

    if not device:
        with page.expect_download() as dl:
            page.get_by_role('button', name='Exporter mes données').click()
        data = json.loads(Path(dl.value.path()).read_text())
        assert data['app'] == 'mon-budget' and data['version'] == 3
        assert data['data']['loans'] == []
        assert len(data['data']['transactions']) == 19, len(data['data']['transactions'])
        assert 'shortcut_token' not in data['data']['settings'] and 'snapshot' not in data['data']['settings']
        assert any(r['action'] == 'rembourse' for r in data['data']['merchant_rules'])

        # Synchronisation : une deuxième fenêtre se met à jour toute seule
        other = ctx.new_page()
        other.clock.set_fixed_time(datetime(2026, 6, 6, 9))
        other.on('pageerror', lambda e: errors.append(f'[{tag} fenêtre 2] {e}'))
        other.goto(URL)
        other.locator('#tabs [data-view="mois"]').click()
        assert text(other.get_by_test_id('depenses')) == '830,00 €'
        page.locator('#tabs [data-view="mois"]').click()
        add(page, '7', 'Courses')
        expect(other.get_by_test_id('depenses')).to_have_text('837,00\xa0€', timeout=5000)
        other.close()

    ctx.close()
    b.close()
    print(f'✓ {tag}')


def wizard(pw, errors):
    """Un ami qui démarre de zéro avec l'assistant (paie le 26)."""
    b, ctx, page = new_page(pw, 'iPhone 13', errors, 'assistant', datetime(2026, 9, 27, 10))
    page.get_by_role('button', name='Commencer').click()
    page.locator('[data-wiz="income"]').fill('1800')
    page.locator('[data-wiz="payDay"]').fill('26')
    page.locator('[data-wiz="name"]').fill('MARTIN LEA')
    page.get_by_role('button', name='Continuer').click()
    page.locator('[data-wiz="fixed.0.amount"]').fill('650')
    page.locator('[data-wiz="fixed.1.amount"]').fill('15')
    page.get_by_role('button', name='Continuer').click()
    page.locator('[data-wiz="budgets.Courses"]').fill('200')
    page.locator('[data-wiz="budgets.Bar / resto"]').fill('80')
    page.get_by_role('button', name='Continuer').click()
    page.locator('[data-wiz="total"]').fill('1000')
    page.locator('[data-wiz="end"]').select_option('2027-03')
    page.get_by_role('button', name='Continuer').click()
    recap = text(page.locator('.result'))
    assert '968,33' in recap, recap                                  # 1 800 − 665 − 1 000/6
    page.get_by_role('button', name='C’est parti !').click()
    expect(page.get_by_test_id('restant')).to_have_text('968,33\xa0€', timeout=5000)
    assert 'du 26 sept. au 25 oct.' in text(page.locator('.month-head')), text(page.locator('.month-head'))
    page.locator('.banner.action').click()                           # « Salaire reçu »
    page.locator('[data-form="salary"] [name="income"]').fill('1850')
    page.locator('[data-form="salary"]').get_by_role('button', name='Enregistrer').click()
    expect(page.get_by_test_id('restant')).to_have_text('1 018,33\xa0€')
    ctx.close()
    b.close()
    print('✓ assistant')


def money_of(loc):
    return float(text(loc).replace(' €', '').replace(' ', '').replace(',', '.'))


def v3(pw, errors, tmp):
    """Avances partielles, étalement, à recevoir, import préparé, placements et prêts (paie le 26)."""
    b, ctx, page = new_page(pw, None, errors, 'v3', datetime(2026, 11, 2, 10))
    page.get_by_role('button', name='Commencer').click()
    page.locator('[data-wiz="income"]').fill('1660')
    page.locator('[data-wiz="payDay"]').fill('26')
    page.locator('[data-wiz="name"]').fill('MARTIN LEA')
    for _ in range(4):
        page.get_by_role('button', name='Continuer').click()
    page.get_by_role('button', name='C’est parti !').click()
    expect(page.get_by_test_id('depenses')).to_be_visible(timeout=5000)
    base = money_of(page.get_by_test_id('depenses'))

    # Avance : 150 € de places, on me doit 125 € → seuls 25 € comptent
    page.locator('#fab').click()
    page.locator('#f-amount').fill('150')
    page.locator('#f-label').fill('Places OM')
    page.locator('#f-reimb').check()
    page.locator('#f-owed').fill('125')
    page.locator('.cat-pick', has_text='Loisirs').click()
    expect(page.locator('#toast')).to_contain_text('ta part 25,00')
    assert abs(money_of(page.get_by_test_id('depenses')) - base - 25) < 0.01
    expect(page.locator('.refunds h2')).to_contain_text('125,00')
    # 25 € reçus d'un ami : il en reste 100
    page.locator('.refunds').get_by_role('button', name='Reçu').click()
    page.locator('[data-form="refund"] [name="amount"]').fill('25')
    page.locator('[data-form="refund"]').get_by_role('button', name='Enregistrer').click()
    expect(page.locator('.refunds h2')).to_contain_text('100,00')
    assert abs(money_of(page.get_by_test_id('depenses')) - base - 25) < 0.01

    # Étaler 209 € sur 3 mois
    add(page, '209', 'Autre', spread=3, label='Billet partagé')
    assert abs(money_of(page.get_by_test_id('depenses')) - base - 25 - 69.67) < 0.01
    # À recevoir sans dépense (vol annulé)
    page.locator('.refunds').get_by_role('button', name='+ On me doit autre chose').click()
    page.locator('[data-form="receivable"] [name="amount"]').fill('29')
    page.locator('[data-form="receivable"] [name="label"]').fill('Volotea')
    page.locator('[data-form="receivable"]').get_by_role('button', name='Ajouter').click()
    expect(page.locator('.refunds h2')).to_contain_text('129,00')
    assert abs(money_of(page.get_by_test_id('depenses')) - base - 94.67) < 0.01

    # Relevé préparé (colonnes Catégorie, Étaler, On me doit, Remboursement de)
    csv = tmp / 'prepare.csv'
    csv.write_text(
        'Compte LCL\nDate;Libellé;Montant;Catégorie;Étaler sur (mois);On me doit (€);Remboursement de\n'
        '27/10/2026;CB SNCF-VOYAGEURS 26/10/26;-12,90;Transport;;12,90;\n'
        '27/10/2026;CB POKE SHOP 26/10/26;-23,28;Bar / resto;;;\n'
        '27/10/2026;VIR INST M. AMI UN;25,00;;;;Places OM\n'
        '28/10/2026;VIR INST Mme AMIE DEUX;12,90;;;;CB SNCF-VOYAGEURS 26/10/26\n'
        '28/10/2026;VIREMENT TEST;-90,00;Autre;3;;\n', encoding='utf-8')
    page.set_input_files('#statement-file', str(csv))
    expect(page.get_by_role('heading', name='Relevé LCL')).to_be_visible(timeout=10000)
    ami = page.locator('.imp-row', has=page.locator('.imp-label', has_text='AMI UN')).locator('select')
    assert 'Places OM' in ami.locator('option:checked').inner_text()
    amie = page.locator('.imp-row', has=page.locator('.imp-label', has_text='AMIE DEUX')).locator('select')
    assert 'SNCF' in amie.locator('option:checked').inner_text()
    assert 'étalé sur 3 mois' in text(page.locator('.imp-row', has=page.locator('.imp-label', has_text='VIREMENT TEST')))
    page.get_by_role('button', name='Importer 5 opérations').click()
    expect(page.locator('#toast')).to_contain_text('opérations ajoutées', timeout=10000)
    # SNCF remboursée dans le même relevé : soldée ; OM : il reste 75 € ; + Volotea 29 €
    expect(page.locator('.refunds h2')).to_contain_text('104,00')
    assert abs(money_of(page.get_by_test_id('depenses')) - base - 94.67 - 23.28 - 30) < 0.01

    # Ré-import corrigé : POKE SHOP étalé sur 2 mois
    csv.write_text(csv.read_text(encoding='utf-8').replace('Bar / resto;;;', 'Bar / resto;2;;'), encoding='utf-8')
    page.set_input_files('#statement-file', str(csv))
    expect(page.get_by_role('heading', name='Relevé LCL')).to_be_visible(timeout=10000)
    assert 'À corriger\n5' in text(page.locator('.stats')), text(page.locator('.stats'))
    page.get_by_role('button', name='Corriger 5 opérations').click()
    expect(page.locator('#toast')).to_contain_text('5 corrigées', timeout=10000)
    expect(page.locator('.refunds h2')).to_contain_text('104,00')          # rien de compté deux fois
    assert abs(money_of(page.get_by_test_id('depenses')) - base - 94.67 - 11.64 - 30) < 0.01

    # ── Patrimoine : placements et prêts ──
    page.locator('#tabs [data-view="comptes"]').click()
    page.get_by_role('button', name='+ Ajouter un compte').click()
    page.locator('.chip', has_text='PEA').click()
    form = page.locator('[data-form="account"]')
    expect(form.locator('[name="tax"]')).to_have_value('18,6')
    form.locator('[name="balance"]').fill('33330')
    form.locator('[name="rate"]').fill('6')
    form.get_by_role('button', name='Enregistrer').click()
    page.locator('[data-tab="placements"]').click()
    page.locator('[data-act="horizon"][data-years="10"]').click()
    # 33 330 € à 6 %/an pendant 10 ans = 59 688,95 € ; impôts 18,6 % des gains
    assert text(page.get_by_test_id('projection')) == '54 786,19 €', text(page.get_by_test_id('projection'))
    expect(page.locator('svg.chart.invest')).to_be_visible()
    page.locator('[data-tab="prets"]').click()
    page.get_by_role('button', name='+ Ajouter un prêt').click()
    f = page.locator('[data-form="loan"]')
    f.locator('[name="name"]').fill('Prêt étudiant')
    f.locator('[name="principal"]').fill('33330')
    f.locator('[name="rate"]').fill('0,9')
    f.locator('[name="months"]').fill('84')
    f.locator('[name="start_date"]').fill('2026-09-01')
    f.locator('[name="deferral_months"]').fill('24')
    f.locator('[name="insurance"]').fill('0,3')
    f.get_by_role('button', name='Enregistrer').click()
    card = page.get_by_test_id('pret')
    expect(card).to_contain_text('33,33')                                 # différé : intérêts + assurance
    assert '417,89' in text(card), text(card)                              # puis mensualité complète
    assert 'Capital restant dû\n33 330,00' in text(card)
    expect(page.get_by_test_id('patrimoine')).to_have_text('0,00\xa0€')   # 33 330 sur le PEA − 33 330 de prêt
    page.locator('[data-tab="placements"]').click()
    assert 'plus que le prêt' in text(page.locator('.compare-loan'))
    page.locator('[data-tab="prets"]').click()
    page.get_by_role('button', name='Ajouter 33,33 € aux charges fixes du mois').click()
    expect(page.locator('#toast')).to_contain_text('charges fixes')

    # Réglages : adresse complète et jeton copiables
    page.locator('#tabs [data-view="reglages"]').click()
    expect(page.locator('#view')).to_contain_text('Disponible avec un compte en ligne')
    ctx.close()
    b.close()
    print('✓ v3')


def main():
    srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '-d', str(ROOT)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)
    errors = []
    try:
        with sync_playwright() as pw:
            scenario(pw, 'iPhone 13', errors)
            scenario(pw, None, errors)
            wizard(pw, errors)
            import tempfile
            with tempfile.TemporaryDirectory() as tmp:
                v3(pw, errors, Path(tmp))
    finally:
        srv.terminate()
    if errors:
        print('Erreurs dans la console :', *errors, sep='\n  ')
        sys.exit(1)
    print('Tous les tests de bout en bout passent.')


if __name__ == '__main__':
    main()
